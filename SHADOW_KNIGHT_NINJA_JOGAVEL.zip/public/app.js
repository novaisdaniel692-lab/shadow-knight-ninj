
let state=null;
const KEY="shadow_knight_ninja_save_v1";
function defaultState(){
  return {
    player:{id:"player-1",name:"Shadow",level:1,xp:0,coins:250,realBalance:0,
      completedMissions:[],completedLevels:[],achievements:[],inventory:[]},
    transactions:[{amount:250,description:"Bônus inicial",status:"Concluído",createdAt:new Date().toISOString()}],
    withdrawals:[],
    missions:[
      {id:"m1",title:"Primeiro passo",description:"Complete a fase 1",reward:100,goal:"level",target:1},
      {id:"m2",title:"Caçador de moedas",description:"Colete 50 moedas",reward:75,goal:"coinsCollected",target:50},
      {id:"m3",title:"Ninja diário",description:"Entre no jogo e reivindique o bônus",reward:50,goal:"daily",target:1}
    ],
    leaderboard:[{name:"Shadow",level:1,coins:250}],
    dailyClaimed:false
  }
}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function load(){
  try{state=JSON.parse(localStorage.getItem(KEY))||defaultState()}catch(e){state=defaultState()}
  if(!state.leaderboard)state.leaderboard=[{name:"Shadow",level:state.player.level,coins:state.player.coins}];
  render();
}
function addTx(amount,description,status="Concluído"){
  state.transactions.unshift({amount,description,status,createdAt:new Date().toISOString()})
}
function flash(msg){
  let el=document.getElementById("flash");
  if(!el){el=document.createElement("div");el.id="flash";el.style.cssText="position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#111;color:#fff;padding:12px 18px;border-radius:12px;z-index:9999;font-weight:700;box-shadow:0 8px 30px #0008";document.body.appendChild(el)}
  el.textContent=msg;el.style.display="block";clearTimeout(window._ft);window._ft=setTimeout(()=>el.style.display="none",1800)
}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));let s=document.getElementById(id);if(s)s.classList.add("active");let m=document.getElementById("menu");if(m)m.classList.remove("open");render()}
function toggleMenu(){document.getElementById("menu").classList.toggle("open")}
function render(){
 if(!state)return; const p=state.player;
 ["walletCoins","gameCoins"].forEach(id=>{let e=document.getElementById(id);if(e)e.textContent=p.coins});
 let e;
 e=document.getElementById("profileName");if(e)e.textContent=p.name;
 e=document.getElementById("levelText");if(e)e.textContent="Nível "+p.level;
 e=document.getElementById("statLevel");if(e)e.textContent=p.level;
 e=document.getElementById("statLevels");if(e)e.textContent=p.completedLevels.length;
 e=document.getElementById("statAch");if(e)e.textContent=p.achievements?.length||0;
 const need=p.level*250;e=document.getElementById("xpBar");if(e)e.style.width=Math.min(100,p.xp/need*100)+"%";
 e=document.getElementById("txList");if(e)e.innerHTML=state.transactions.map(t=>`<div class="row"><span>${t.description}<small>${new Date(t.createdAt).toLocaleString("pt-BR")} · ${t.status}</small></span><b>${t.amount>0?"+":""}${t.amount} 🪙</b></div>`).join("")||'<p class="muted">Sem histórico.</p>';
 e=document.getElementById("withdrawList");if(e)e.innerHTML=state.withdrawals.map(w=>`<div class="row"><span>${w.amount} 🪙 · ${w.method}<small>${new Date(w.createdAt).toLocaleString("pt-BR")}</small></span><b>${w.status}</b></div>`).join("")||'<p class="muted">Nenhuma solicitação.</p>';
 e=document.getElementById("missionsList");if(e)e.innerHTML=state.missions.map(m=>{const done=p.completedMissions.includes(m.id);return `<div class="mission"><div class="mission-top"><div><b>${m.title}</b><p class="muted">${m.description}</p></div><span class="tag">+${m.reward} 🪙</span></div><button ${done?"disabled":""} onclick="claim('${m.id}')">${done?"✓ Resgatada":"Resgatar recompensa"}</button></div>`}).join("");
 e=document.getElementById("rankList");if(e)e.innerHTML=state.leaderboard.map((x,i)=>`<div class="row"><span>#${i+1} 🥷 ${x.name}</span><b>Nv.${x.level} · ${x.coins} 🪙</b></div>`).join("");
}
function startGame(){show("game");document.getElementById("levelLabel").textContent="FASE "+Math.min(10,state.player.completedLevels.length+1)}
function collectReward(){state.player.coins+=25;state.player.xp+=25;addTx(25,"Coleta de moedas");save();render();flash("25 moedas virtuais coletadas!")}
function completeLevel(){
 const level=Math.min(10,state.player.completedLevels.length+1);
 if(!state.player.completedLevels.includes(level)){state.player.completedLevels.push(level);state.player.level=Math.max(state.player.level,Math.min(10,level+1));state.player.xp+=250;state.player.coins+=100;addTx(100,"Recompensa da fase "+level);save()}
 render();document.getElementById("levelLabel").textContent="FASE "+Math.min(10,state.player.completedLevels.length+1);flash("Fase concluída! +100 moedas.")
}
function move(dir){const el=document.getElementById("player");let x=parseInt(getComputedStyle(el).left)||80;x=Math.max(10,Math.min(420,x+dir*35));el.style.left=x+"px"}
function jump(){const el=document.getElementById("player");el.style.transform="translateY(-100px)";setTimeout(()=>el.style.transform="",350)}
function attack(){const e=document.getElementById("enemy");e.style.transform="translateX(35px) rotate(15deg)";setTimeout(()=>e.style.transform="",220);flash("Ataque executado!")}
function dodge(){const el=document.getElementById("player");el.style.transform="translateX(70px) scale(.8)";setTimeout(()=>el.style.transform="",250)}
function claim(id){
 const m=state.missions.find(x=>x.id===id); if(!m||state.player.completedMissions.includes(id))return;
 if(m.goal==="level" && state.player.completedLevels.length<m.target){flash("Conclua a fase 1 primeiro.");return}
 if(m.goal==="coinsCollected" && state.player.coins<50){flash("Colete pelo menos 50 moedas.");return}
 state.player.completedMissions.push(id);state.player.coins+=m.reward;addTx(m.reward,"Missão: "+m.title);save();render();flash("Recompensa da missão adicionada.")
}
function daily(){
 if(state.dailyClaimed){flash("Bônus diário já resgatado.");return}
 state.dailyClaimed=true;state.player.coins+=50;addTx(50,"Bônus diário");save();render();flash("Bônus diário: +50 moedas!")
}
function resetGame(){if(confirm("Apagar todo o progresso deste navegador?")){localStorage.removeItem(KEY);load();show("home");flash("Progresso reiniciado.")}}
window.addEventListener("load",load);
